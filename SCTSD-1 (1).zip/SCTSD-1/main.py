import requests
from bs4 import BeautifulSoup
import pandas as pd


URL = "https://books.toscrape.com/catalogue/page-1.html"
headers = {
    "User-Agent": "Mozilla/5.0"
}

product_names = []
product_prices = []
product_ratings = []

def get_rating_class(rating_str):
    ratings_dict = {
        "One": 1,
        "Two": 2,
        "Three": 3,
        "Four": 4,
        "Five": 5
    }
    return ratings_dict.get(rating_str, 0)

for page in range(1, 4):
    print(f"Scraping page {page}...")
    page_url = f"https://books.toscrape.com/catalogue/page-{page}.html"
    response = requests.get(page_url, headers=headers)
    soup = BeautifulSoup(response.content, "html.parser")

    products = soup.find_all("article", class_="product_pod")

    for product in products:
        name = product.h3.a["title"]
        price = product.find("p", class_="price_color").text.strip()
        rating = product.p["class"][1]
        numeric_rating = get_rating_class(rating)

        product_names.append(name)
        product_prices.append(price)
        product_ratings.append(numeric_rating)

data = {
    "Product Name": product_names,
    "Price": product_prices,
    "Rating (1-5)": product_ratings
}
df = pd.DataFrame(data)
df.to_csv("products.csv", index=False)

print("✅ Data saved to products.csv")
